<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
include("../auth/header.php");
include("../auth/sidebar.php");
include 'connection1.php';
?>

<link rel="stylesheet" href="popup_style.css">
<style>
    .table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin-bottom: 1rem;
        color: #212529;
    }
    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }
    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
        background-color: #f8f9fa;
        color: #495057;
        font-weight: bold;
    }
    .table tbody + tbody {
        border-top: 2px solid #dee2e6;
    }
    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.075);
    }
    .table-responsive {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    .popup-form {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
    }
    .popup-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 50%;
        max-width: 500px;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }
    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
    .popup-content h2 {
        text-align: center;
        margin-bottom: 20px;
    }
    .popup-content form {
        display: flex;
        flex-direction: column;
    }
    .popup-content input,
    .popup-content textarea {
        margin-bottom: 10px;
        padding: 5px;
    }
    .popup-content button {
        width: 50%;
        margin: 10px auto;
    }
</style>

<div class="page-content">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Client Data</h6>
                    <?php
                    if(isset($_SESSION['success_message'])) {
                        echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                        unset($_SESSION['success_message']);
                    }
                    if(isset($_SESSION['error_message'])) {
                        echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                        unset($_SESSION['error_message']);
                    }
                    ?>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>DOB</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th>Birth Certificate</th>
                                    <th>NID No.</th>
                                    <th>Passport Number</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM clients";
                                $result = $conn->query($sql);
                                
                                if($result->num_rows > 0){
                                    while($row = $result->fetch_array()){
                                ?>
                                <tr>
                                    <td><?=$row['id'];?></td>
                                    <td><?=$row['name'];?></td>
                                    <td><?=$row['gender'];?></td>
                                    <td><?=$row['dob'];?></td>
                                    <td><?=$row['email'];?></td>
                                    <td><?=$row['mobile'];?></td>
                                    <td><?=$row['address'];?></td>
                                    <td><?=$row['birth_certificate'];?></td>
                                    <td><?=$row['nid_no'];?></td>
                                    <td><?=$row['passport_number'];?></td>
                                    <td><?php echo ($row['status'] == "0") ? "Active" : "Inactive";?></td>
                                    <td>
                                        <button class="btn btn-danger btn-sm" onclick="openDeleteForm(<?=$row['id'];?>, '<?=$row['name'];?>', '<?=$row['email'];?>')"><i class="fa fa-trash text-white" aria-hidden="true"></i></button>
                                        <a class="btn btn-success btn-sm" href="edit_client.php?id=<?=$row['id'];?>"><i class="fa fa-edit text-white" aria-hidden="true"></i></a>
                                    </td>
                                    <td>
                                        <?php 
                                        if($row['status'] == "0") {
                                            echo "<button onclick='openDeactivateForm(".$row['id'].", \"".$row['name']."\", \"".$row['email']."\")' class='btn btn-danger btn-sm'>Deactivate</button>";
                                        } else {
                                            echo "<button onclick='openActivateForm(".$row['id'].", \"".$row['name']."\", \"".$row['email']."\")' class='btn btn-success btn-sm'>Activate</button>";
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php        
                                    }
                                } else {
                                    echo "<tr><td colspan='13'>No records found</td></tr>";
                                }
                                
                                $conn->close(); 
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Activate Form -->
<div id="activateForm" class="popup-form">
    <div class="popup-content">
        <span class="close" onclick="closeForm('activateForm')">&times;</span>
        <h2>Activate Client</h2>
        <form action="activate.php" method="POST">
            <input type="hidden" id="activateId" name="id">
            <input type="text" id="activateName" name="client_name" placeholder="Name" readonly>
            <input type="email" id="activateEmail" name="client_email" placeholder="Email" readonly>
            <input type="text" name="activated_by_name" placeholder="Your Name" required>
            <input type="text" name="activated_by_email" placeholder="Your Email" value="<?php echo $_SESSION['username']; ?>" readonly>
            <textarea id="activateReason" name="reason" placeholder="Reason for Activation" required></textarea>
            <input type="hidden" name="activate_datetime" value="<?php echo date('Y-m-d H:i:s'); ?>">
            <button type="submit" class="btn btn-success">Activate</button>
        </form>
    </div>
</div>

<!-- Deactivate Form -->
<div id="deactivateForm" class="popup-form">
    <div class="popup-content">
        <span class="close" onclick="closeForm('deactivateForm')">&times;</span>
        <h2>Deactivate Client</h2>
        <form action="deactivate.php" method="POST">
            <input type="hidden" id="deactivateId" name="id">
            <input type="text" id="deactivateName" name="client_name" placeholder="Name" readonly>
            <input type="email" id="deactivateEmail" name="client_email" placeholder="Email" readonly>
            <input type="text" name="deactivated_by_name" placeholder="Your Name" required>
            <input type="text" name="deactivated_by_email" placeholder="Your Email" value="<?php echo $_SESSION['username']; ?>" readonly>
            <textarea id="deactivateReason" name="reason" placeholder="Reason for Deactivation" required></textarea>
            <input type="hidden" name="deactivate_datetime" value="<?php echo date('Y-m-d H:i:s'); ?>">
            <button type="submit" class="btn btn-danger">Deactivate</button>
        </form>
    </div>
</div>

<!-- Delete Form -->
<div id="deleteForm" class="popup-form">
    <div class="popup-content">
        <span class="close" onclick="closeForm('deleteForm')">&times;</span>
        <h2>Delete Client</h2>
        <form action="delete_client.php" method="POST">
            <input type="hidden" id="deleteId" name="id">
            <input type="text" id="deleteName" name="client_name" placeholder="Name" readonly>
            <input type="email" id="deleteEmail" name="client_email" placeholder="Email" readonly>
            <input type="text" name="deleted_by_name" placeholder="Your Name" required>
            <input type="text" name="deleted_by_email" placeholder="Your Email" value="<?php echo $_SESSION['username']; ?>" readonly>
            <textarea id="deleteReason" name="reason" placeholder="Reason for Deletion" required></textarea>
            <input type="hidden" name="delete_datetime" value="<?php echo date('Y-m-d H:i:s'); ?>">
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>

<script>
function openActivateForm(id, name, email) {
    document.getElementById('activateId').value = id;
    document.getElementById('activateName').value = name;
    document.getElementById('activateEmail').value = email;
    document.getElementById('activateForm').style.display = 'block';
}

function openDeactivateForm(id, name, email) {
    document.getElementById('deactivateId').value = id;
    document.getElementById('deactivateName').value = name;
    document.getElementById('deactivateEmail').value = email;
    document.getElementById('deactivateForm').style.display = 'block';
}

function openDeleteForm(id, name, email) {
    document.getElementById('deleteId').value = id;
    document.getElementById('deleteName').value = name;
    document.getElementById('deleteEmail').value = email;
    document.getElementById('deleteForm').style.display = 'block';
}

function closeForm(formId) {
    document.getElementById(formId).style.display = 'none';
}

// Close the popup if the user clicks outside of it
window.onclick = function(event) {
    if (event.target.className === 'popup-form') {
        event.target.style.display = "none";
    }
}
</script>

<?php 
include("../auth/footer.php");
?>



