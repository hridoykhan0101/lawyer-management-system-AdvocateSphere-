// Function to create and append the footer
function createFooter() {
    // Create the footer element
    var footer = document.createElement('footer');
    
    // Set the inner HTML of the footer
    footer.innerHTML = 'Copyright © 2024 Project Develop by <a href="https://9amsolution.com/" target="_blank">9AM Solution</a>';
    
    // Style the footer
    footer.style.position = 'fixed';
    footer.style.left = '0';
    footer.style.bottom = '0';
    footer.style.width = '100%';
    footer.style.backgroundColor = '#f8f9fa';
    footer.style.color = 'black';
    footer.style.textAlign = 'center';
    footer.style.padding = '10px 0';
    footer.style.fontSize = '14px';
    
    // Style the link
    var link = footer.querySelector('a');
    link.style.color = 'red';
    link.style.textDecoration = 'none';
    
    // Append the footer to the body
    document.body.appendChild(footer);
}

// Call the function when the window has finished loading
window.onload = createFooter;