<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Database connection
$servername = "localhost"; // Your database server name
$dbusername = "root";      // Your database username
$dbpassword = "";          // Your database password
$dbname = "law";           // Your database name

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Preset credentials for admin
    $preset_username = 'mayuri.infospace@gmail.com';
    $preset_password = 'admin';

    $msg = '';

    // Verify reCAPTCHA
    $recaptcha = $_POST['g-recaptcha-response'];
    $secret_key = '6LcXEiAhAAAAALaf8ygYOebTAENC3QsvAMjXFuuB';
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response=' . $recaptcha;
    $response = file_get_contents($url);
    $response = json_decode($response);

    if ($response->success == true) {
        // Check if username matches the preset username
        if ($username === $preset_username) {
            // Check if password matches the preset password
            if ($password === $preset_password) {
                // Admin login
                $_SESSION['username'] = $username;
                $_SESSION['user_role'] = 'admin';
                ?>
                <div class="popup popup--icon -success js_success-popup popup--visible">
                    <div class="popup__background"></div>
                    <div class="popup__content">
                        <h3 class="popup__content__title">Success</h3>
                        <p>Login Successfully</p>
                        <p><?php echo "<script>setTimeout(\"location.href = 'dashboard.php';\",1500);</script>"; ?></p>
                    </div>
                </div>
                <?php
            } else {
                // Check advocates table if preset password doesn't match
                $stmt = $conn->prepare("SELECT * FROM advocates WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    // Assuming passwords are stored as plain text (not recommended for production)
                    if ($row['password'] === $password) {
                        $_SESSION['username'] = $username;
                        $_SESSION['user_role'] = 'advocate';
                        ?>
                        <div class="popup popup--icon -success js_success-popup popup--visible">
                            <div class="popup__background"></div>
                            <div class="popup__content">
                                <h3 class="popup__content__title">Success</h3>
                                <p>Login Successfully</p>
                                <p><?php echo "<script>setTimeout(\"location.href = 'advocate_dashboard.php';\",1500);</script>"; ?></p>
                            </div>
                        </div>
                        <?php
                    } else {
                        $msg = 'Invalid Password';
                    }
                } else {
                    $msg = 'Invalid Email or Password';
                }
            }
        } else {
            // Advocate login
            $stmt = $conn->prepare("SELECT * FROM advocates WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                // Assuming passwords are stored as plain text (not recommended for production)
                if ($row['password'] === $password) {
                    $_SESSION['username'] = $username;
                    ?>
                    <div class="popup popup--icon -success js_success-popup popup--visible">
                        <div class="popup__background"></div>
                        <div class="popup__content">
                            <h3 class="popup__content__title">Success</h3>
                            <p>Login Successfully</p>
                            <p><?php echo "<script>setTimeout(\"location.href = 'advocate_dashboard.php';\",1500);</script>"; ?></p>
                        </div>
                    </div>
                    <?php
                } else {
                    $msg = 'Invalid Password';
                }
            } else {
                $msg = 'Invalid Email or Password';
            }
        }
    } else {
        echo '<script>alert("Please verify Google reCAPTCHA")</script>';
    }

    if (!empty($msg)) {
        echo '<div class="popup popup--icon -error js_error-popup popup--visible">
                <div class="popup__background"></div>
                <div class="popup__content">
                    <h3 class="popup__content__title">Error</h3>
                    <p>' . $msg . '</p>
                    <p><a href="login.php"><button class="button button--error" data-for="js_error-popup">Close</button></a></p>
                </div>
            </div>';
    }
}

$conn->close();
?>
