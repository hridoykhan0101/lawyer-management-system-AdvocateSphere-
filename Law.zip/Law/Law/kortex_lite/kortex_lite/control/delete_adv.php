<?php
include 'connection1.php';

if (isset($_GET['id'])) {
    $advocate_id = $_GET['id'];
    
    // Start a transaction
    $conn->begin_transaction();

    try {
        // Delete from advocates table
        $sql1 = "DELETE FROM advocates WHERE id = ?";
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param("i", $advocate_id);
        $stmt1->execute();

        // Delete from users table
        $sql2 = "DELETE FROM user WHERE id = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("i", $advocate_id);
        $stmt2->execute();

        // Commit the transaction
        $conn->commit();
        
        ?>
        <link rel="stylesheet" href="popup_style.css">
        <div class="popup popup--icon -success js_success-popup popup--visible">
            <div class="popup__background"></div>
            <div class="popup__content">
                <h3 class="popup__content__title">Success</h3>
                <p>Record deleted successfully</p>
                <p>
                    <?php echo "<script>setTimeout(\"location.href = 'advocate_data.php';\",1500);</script>"; ?>
                </p>
            </div>
        </div>
        <?php
    } catch (Exception $e) {
        // Rollback the transaction in case of an error
        $conn->rollback();
        echo "SQL error: " . $e->getMessage();
    }

    // Close statements
    $stmt1->close();
    $stmt2->close();
}
$conn->close();
?>
