<?php
session_start();
error_reporting(0);
include("../auth/header.php");
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
?>
<div class="page-content">

<?php 
include 'connection1.php';
if(isset($_POST['submit']))
{   
    $currentpassword = $_POST['currentpassword'];
    $newpassword = $_POST['newpassword'];
    $confirmpassword = $_POST['confirmpassword'];
    
    $sql = "SELECT * FROM user WHERE id = '".$_SESSION['id']."' ";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        if ($currentpassword == $row['password'])
        {
            // Check if new password and confirm password are the same
            if ($newpassword == $confirmpassword)
            {
                // Change password
                $sql = "UPDATE user SET password = '".$newpassword."' WHERE id = '".$_SESSION['id']."' ";
                mysqli_query($conn, $sql);

                echo "<script>alert('Password has been changed');
                       window.location.href='dashboard.php';
                      </script>";
            }
            else
            {
                echo "<script>alert('New password and confirm password do not match');
                       window.location.href='user_password.php';
                      </script>";  
            }
        }
        else
        {
            echo "<script>alert('Current password is not correct');
                   window.location.href='user_password.php';
                  </script>";
        }
    }
}
?>

<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="exampleInputText1" class="form-label">Enter your current password</label>
                        <input type="password" class="form-control" name="currentpassword" id="exampleInputText1" required>
                    </div>

                    <div class="mb-3">
                        <label for="exampleInputText1" class="form-label">Enter your new password</label>
                        <input type="password" class="form-control" name="newpassword" id="exampleInputText1" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="exampleInputText1" class="form-label">Confirm new password</label>
                        <input type="password" class="form-control" name="confirmpassword" id="exampleInputText1" required>
                    </div>
                    
                    <input type="submit" class="btn btn-primary" name="submit" value="Update Password">
                </form>
                <br><br>
            </div>
        </div>
    </div>
</div> 
</div>

<?php 
include("../auth/footer.php");
?>
