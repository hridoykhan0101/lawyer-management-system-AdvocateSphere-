<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

include 'connection1.php'; 

if (isset($_GET['id'])) {
    $uid = intval($_GET['id']); // Ensure $uid is an integer to prevent SQL injection

    // Prepare a parameterized query to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM clients WHERE id = ?");
    $stmt->bind_param("i", $uid);

    if ($stmt->execute()) {
        // Success case
        echo '<link rel="stylesheet" href="popup_style.css">';
        echo '<div class="popup popup--icon -success js_success-popup popup--visible">
                <div class="popup__background"></div>
                <div class="popup__content">
                    <h3 class="popup__content__title">Success</h3>
                    <p>Record deleted successfully</p>
                    <p>';
        echo "<script>setTimeout(function() { window.location.href = 'client_data_adv.php'; }, 1500);</script>";
        echo '   </p>
                </div>
              </div>';
    } else {
        // Error case
        echo "SQL error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>