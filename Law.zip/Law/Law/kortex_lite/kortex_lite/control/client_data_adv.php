<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
include("../auth/header.php");
include("../auth/advocate_sidebar.php");
?>
<link rel="stylesheet" href="popup_style.css">
<div class="page-content">
    <?php
    if (isset($_GET['id'])) { ?>
        <div class="popup popup--icon -question js_question-popup popup--visible">
            <div class="popup__background"></div>
            <div class="popup__content">
                <h3 class="popup__content__title">Sure</h3>
                <p>Are You Sure To Delete This Record?</p>
                <p></p>
                <p>
                    <a href="delete_client_adv.php?id=<?php echo htmlspecialchars($_GET['id']); ?>" class="btn btn-success" data-for="js_success-popup">Yes</a>
                    <a href="client_data_adv.php" class="btn btn-danger" data-for="js_success-popup">No</a>
                </p>
            </div>
        </div>
    <?php } ?>
    <div class="row mb-4">
        <div class="col-md-6">
            <a href="adv_add.php" class="btn btn-primary">Add New Client</a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Client Data</h6>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>DOB</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                include 'connection1.php';

                                $sql = "SELECT * FROM clients";
                                $result = $conn->query($sql);

                                if ($result === false) {
                                    echo "SQL error: " . $conn->error;
                                } else {
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) { ?>
                                            <tr>
                                                <td><?= htmlspecialchars($row['id']); ?></td>
                                                <td><?= htmlspecialchars($row['name']); ?></td>
                                                <td><?= htmlspecialchars($row['gender']); ?></td>
                                                <td><?= htmlspecialchars($row['dob']); ?></td>
                                                <td><?= htmlspecialchars($row['email']); ?></td>
                                                <td><?= htmlspecialchars($row['mobile']); ?></td>
                                                <td><?= htmlspecialchars($row['address']); ?></td>
                                                <td><?= $row['status'] == "0" ? "Active" : "Inactive"; ?></td>
                                                <td>
                                                    <a class="btn btn-danger" href="client_data_adv.php?id=<?= htmlspecialchars($row['id']); ?>"><i class="fa fa-trash text-white" aria-hidden="true"></i></a>
                                                    <a class="btn btn-success" href="edit_client_adv.php?id=<?= htmlspecialchars($row['id']); ?>"><i class="fa fa-edit text-white" aria-hidden="true"></i></a>
                                                </td>
                                                <td>
                                                    <?php if ($row['status'] == "0") {
                                                        echo "<a href='deactivate_client_adv.php?id=" . htmlspecialchars($row['id']) . "' class='btn btn-danger'>Deactivate</a>";
                                                    } else {
                                                        echo "<a href='activate_client_adv.php?id=" . htmlspecialchars($row['id']) . "' class='btn btn-success'>Activate</a>";
                                                    } ?>
                                                </td>
                                            </tr>
                                        <?php }
                                    } else {
                                        echo "<tr><td colspan='10'>No records found</td></tr>";
                                    }
                                }

                                $conn->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include("../auth/footer.php"); ?>
