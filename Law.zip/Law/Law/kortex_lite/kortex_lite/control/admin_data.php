<?php 
session_start();
include("../auth/header.php");
include("../auth/sidebar.php");

// Check if the user is logged in
if(!isset($_SESSION['username'])) {
    header("Location: admin_login.php");
    exit();
}

// Set session expiry time
$now = time();
if($now > $_SESSION['expire']) {
    session_destroy();
    header("Location: admin_login.php");
    exit();
}
?>

<div class="page-content">
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Tables</a></li>
            <li class="breadcrumb-item active" aria-current="page">Data Table</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Admin Data</h6>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Username</th>
                                    <th align="center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $servername = 'localhost';
                                $username = 'root';
                                $password = '';
                                $dbname = "law";
                                $conn = mysqli_connect($servername, $username, $password, $dbname);

                                if(!$conn){
                                    die('Could not Connect MySql Server:' .mysql_error());
                                }

                                $sql = "SELECT * FROM admin";
                                $result = $conn->query($sql);

                                if($result->num_rows > 0){
                                    while($row = $result->fetch_array()){
                                ?>
                                    <tr>
                                        <td><?=$row['id'];?></td>
                                        <td><?=$row['name'];?></td>
                                        <td><?=$row['username'];?></td>
                                        <td><a href="edit_profile.php?id=<?=$row['id'];?>">Edit</a></td>
                                    </tr>
                                <?php
                                    }
                                } else {
                                    echo "<tr><td colspan='4'>No records found</td></tr>";
                                }

                                $conn->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("../auth/footer.php"); ?>
