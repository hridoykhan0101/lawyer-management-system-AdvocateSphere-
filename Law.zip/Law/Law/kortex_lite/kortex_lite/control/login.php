

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'connection1.php';

if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['role'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $msg = '';

    $sql_query = "SELECT id, email, password, role FROM user WHERE email = ? AND password = ? AND role = ? LIMIT 1";

    $stmt = $conn->prepare($sql_query);
    $stmt->bind_param("sss", $username, $password, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $recaptcha = $_POST['g-recaptcha-response'];
        $secret_key = '6LcXEiAhAAAAALaf8ygYOebTAENC3QsvAMjXFuuB';
        $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret_key . '&response=' . $recaptcha;
        $response = file_get_contents($url);
        $response = json_decode($response);

        if ($response->success == true) {          
            $row = $result->fetch_assoc(); 
            if ($row['email'] == $username && $row['password'] == $password && $row['role'] == $role) {
                $_SESSION['username'] = $username;
                $_SESSION['id'] = $row['id'];
                $_SESSION['role'] = $row['role'];
                
                $redirect_page = ($role == 'Senior Advocate') ? 'dashboard.php' : 'advocate_dashboard.php';
                ?> 
                <div class="popup popup--icon -success js_success-popup popup--visible">
                    <div class="popup__background"></div>
                    <div class="popup__content">
                        <h3 class="popup__content__title">
                            Success 
                        </h3>
                        <p>Login Successfully</p>
                        <p>
                            <?php echo "<script>setTimeout(\"location.href = '$redirect_page';\",1500);</script>"; ?>
                        </p>
                    </div>
                </div>
                <?php 
            } else {
                ?>
                <div class="popup popup--icon -error js_error-popup popup--visible">
                    <div class="popup__background"></div>
                    <div class="popup__content">
                        <h3 class="popup__content__title">
                            Error 
                        </h3>
                        <p>Invalid Email, Password, or Role</p>
                        <p>
                            <a href="login.php"><button class="button button--error" data-for="js_error-popup">Close</button></a>
                        </p>
                    </div>
                </div>
                <?php
            }
        } else {
            echo '<script>alert("Please verify Google reCAPTCHA")</script>';
        }
    } else {
        ?>
        <div class="popup popup--icon -error js_error-popup popup--visible">
            <div class="popup__background"></div>
            <div class="popup__content">
                <h3 class="popup__content__title">
                    Error 
                </h3>
                <p>Invalid Email, Password, or Role</p>
                <p>
                    <a href="login.php"><button class="button button--error" data-for="js_error-popup">Close</button></a>
                </p>
            </div>
        </div>
        <?php
    }
}
?>

<!-- The rest of the HTML remains unchanged -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="author" content="Hasinur Rahman">
    <meta name="keywords" content="">
    <title>9AM Solution - AdvocateSphere</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <!-- End fonts -->
    <!-- core:css -->
    <link rel="stylesheet" href="../assets/vendors/core/core.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="../assets/fonts/feather-font/css/iconfont.css">
    <link rel="stylesheet" href="../assets/vendors/flag-icon-css/css/flag-icon.min.css">
    <!-- endinject -->
    <!-- Layout styles -->  
    <link rel="stylesheet" href="../assets/css/demo1/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/nazmul-black-dddck.png" />
    <link rel="stylesheet" href="popup_style.css">
    <!-- Google reCAPTCHA CDN -->
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        body {
            margin: 0;
            font-family: 'Roboto', sans-serif;
        }
        .main-wrapper {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url('../assets/images/login-background.jpg');
            background-size: cover;
            background-position: center;
        }
        .auth-form-wrapper {
            background: rgba(255, 255, 255, 0.7);
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        .login-img {
            display: none;
        }
    </style>
</head>
<body>
    <div class="main-wrapper">
        <div class="auth-form-wrapper">
            <img src="assets/images/nazmul-black-dddck.webp" style="height: 135px;padding-top: 10px;">
            <form class="forms-sample login-form" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="userEmail" class="form-label"></label>
                    <input type="email" class="form-control" name="username" id="userEmail" placeholder="Email"> 
                </div>
                <div class="mb-3">
                    <label for="userPassword" class="form-label"></label>
                    <input type="password" class="form-control" name="password" id="userPassword" autocomplete="current-password" placeholder="Password" id="inputField2">
                    <span toggle="#inputField2" class="fa fa-eye field-icon toggle-password"></span>
                </div>
                <div class="mb-3">
                    <label for="userRole" class="form-label"></label>
                    <select class="form-control" name="role" id="userRole">
                        <option value="">Select Role</option>
                        <option value="Senior Advocate">Senior Advocate</option>
                        <option value="Junior Advocate">Junior Advocate</option>
                    </select>
                </div>
                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="authCheck">
                    <label class="form-check-label" for="authCheck">Remember me</label>
                </div>
                <!-- div to show reCAPTCHA -->
                <div class="g-recaptcha mb-4" data-sitekey="6LcXEiAhAAAAAJRpKyjYMJx0ZXIfmM1COjUj4uAe"></div>
                <div>
                    <input type="submit" name="login" value="Login" class="btn btn-primary w-100 me-2 mb-2 mb-md-0 text-white">
                </div>
            </form>
        </div>
    </div>
    <!-- core:js -->
    <script src="../assets/vendors/core/core.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../assets/vendors/feather-icons/feather.min.js"></script>
    <script src="../assets/js/template.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
    <script>
        function checkForSpaces(event) {
            if (event.target.value.includes(' ')) {
                alert('Space is not allowed!');
                event.target.value = event.target.value.replace(/\s/g, ''); // Remove spaces from input
            }
        }

        var usernameInput = document.getElementById('userEmail');
        var passwordInput = document.getElementById('userPassword');

        usernameInput.addEventListener('input', checkForSpaces);
        passwordInput.addEventListener('input', checkForSpaces);
    </script>
</body>
</html>