<?php 
include("../auth/header.php");
      ?>
<?php include("../auth/sidebar.php");?>

			<div class="page-content">

				  /* <!--  Author Name- Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website - www.mayurik.com -->
    } */

				<div class="row">
					<div class="col-md-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h6 class="card-title">Data Table</h6>
                
                <div class="table-responsive">
                  <table id="dataTableExample" class="table">
                    <thead>
                      <tr>
						<th>name</th>
                        <th>Id</th>
                        <th>Case Name</th>
                        <th>Office</th>
                        <th>Age</th>
                        <th>Id</th>
                        <th>Case Name</th>
						
						
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
						<td>aa</td>
                        <td>Tiger Nixon</td>
                        <td>System Architect</td>
                        <td>Edinburgh</td>
                        <td>61</td>
                        <td>2011/04/25</td>
                        <td>$320,800</td>
                      </tr>
                      
                      <tr>
						<td>ggg</td>
                        <td>Yuri Berry</td>
                        <td>Chief Marketing Officer (CMO)</td>
                        <td>New York</td>
                        <td>40</td>
                        <td>2009/06/25</td>
                        <td>$675,000</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
					</div>
				</div>

			</div>
			
			<!-- partial:../../partials/_footer.html -->
			<?php 
include("../auth/footer.php");
      ?>  /* <!--  Author Name- Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website - www.mayurik.com -->
    } */