<?php
include 'connection1.php';

if (isset($_GET['id'])) {
    $uid = $_GET['id'];
    
    $sql = "UPDATE advocates SET status = 1 WHERE id = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $uid);
        
        if ($stmt->execute()) {
            header("Location: advocate_data.php");
            exit();
        } else {
            echo "Execute error: " . $stmt->error;
        }
        
        $stmt->close();
    } else {
        echo "Prepare error: " . $conn->error;
    }
} else {
    echo "ID parameter not set.";
}

$conn->close();
?>