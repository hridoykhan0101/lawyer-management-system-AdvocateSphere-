<?php
session_start();
include 'connection1.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $client_name = $_POST['client_name'];
    $client_email = $_POST['client_email'];
    $deactivated_by_name = $_POST['deactivated_by_name'];
    $deactivated_by_email = $_POST['deactivated_by_email'];
    $reason = $_POST['reason'];
    $deactivate_datetime = $_POST['deactivate_datetime'];

    // Update the client status to inactive (1)
    $update_sql = "UPDATE clients SET status = '1' WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("i", $id);
    $update_result = $update_stmt->execute();

    if ($update_result) {
        // Insert the deactivation record into de_activate_case table
        $insert_sql = "INSERT INTO de_activate_case (id, client_name, client_email, deactivated_by_name, deactivated_by_email, reason, deactivate_datetime) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("issssss", $id, $client_name, $client_email, $deactivated_by_name, $deactivated_by_email, $reason, $deactivate_datetime);
        $insert_result = $insert_stmt->execute();

        if ($insert_result) {
            $_SESSION['success_message'] = "Client deactivated successfully and record added to de_activate_case.";
        } else {
            $_SESSION['error_message'] = "Error adding record to de_activate_case: " . $conn->error;
        }
    } else {
        $_SESSION['error_message'] = "Error deactivating client: " . $conn->error;
    }

    $update_stmt->close();
    $insert_stmt->close();
    $conn->close();

    header("Location: clients.php");
    exit();
}
?>
