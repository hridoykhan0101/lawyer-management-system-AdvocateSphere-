<?php 
include("../auth/header.php");
      ?>
<?php include("../auth/sidebar.php");?>
      

			<div class="page-content">

				<nav class="page-breadcrumb">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="#">Tables</a></li>
						<li class="breadcrumb-item active" aria-current="page">Basic Tables</li>
					</ol>
			  /* <!--  Author Name- Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website - www.mayurik.com -->
    } */	</nav>

					<div class="col-md-6 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
								<h6 class="card-title">Student Table</h6>
								<p class="text-muted mb-3">Add class <code>.table-hover</code></p>
								<div class="table-responsive">
										<table class="table table-hover">
											<thead>
												<tr>
													<th>#</th>
													<th>first Name</th>
													<th>Last Name</th>
													<th>Subject</th>
													<th>Address</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<th>1</th>
													<td>Mark</td>
													<td>Otto</td>
													<td>Math</td>
													<td>Nasik</td>
												</tr>
												<tr>
													<th>2</th>
													<td>Jacob</td>
													<td>Thornton</td>
													<td>English</td>
													<td>Mumbai</td>
													
												</tr>
												<tr>
													<th>3</th>
													<td>Larry</td>
													<td>the Bird</td>
													<td>Science</td>
													<td>Pune</td>
												</tr>
												<tr>
													<th>4</th>
													<td>Larry</td>
													<td>Jellybean</td>
													<td>Math</td>
													<td>Mumbai</td>
												</tr>
												<tr>
													<th>5</th>
													<td>Larry</td>
													<td>Kikat</td>
													<td>Science</td>
													<td>Nashik</td>
												</tr>
											</tbody>
										</table>
								</div>
              </div>
            </div>
					</div>
				</div>

				

				
				
			<!-- partial:../../partials/_footer.html -->
			
			<!-- partial -->
	
		</div>
	</div>

	<?php 
include("../auth/footer.php");
      ?>