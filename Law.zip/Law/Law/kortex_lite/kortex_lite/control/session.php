<?php
session_start();

	
?>

<?php

	$_SESSION['username']= "aparna@gmail.com";
	$_SESSION['password']= "aparna";
	header("location:client_data.php");
	echo "session variables are set";
?>  /* <!--  Author Name- Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website - www.mayurik.com -->
    } */