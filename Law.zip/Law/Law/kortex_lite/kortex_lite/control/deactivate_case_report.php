<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('location:login.php');
}
include("../auth/header.php");
include("../auth/sidebar.php");
include 'connection1.php';
?>

<div class="page-content">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Deactivated Clients</h6>
                    <?php
                    if (isset($_SESSION['success_message'])) {
                        echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                        unset($_SESSION['success_message']);
                    }
                    if (isset($_SESSION['error_message'])) {
                        echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                        unset($_SESSION['error_message']);
                    }
                    ?>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Client Name</th>
                                    <th>Client Email</th>
                                    <th>Deactivated By Name</th>
                                    <th>Deactivated By Email</th>
                                    <th>Reason</th>
                                    <th>Deactivation Date & Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM de_activate_case";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_array()) {
                                ?>
                                        <tr>
                                            <td><?= $row['id']; ?></td>
                                            <td><?= $row['client_name']; ?></td>
                                            <td><?= $row['client_email']; ?></td>
                                            <td><?= $row['deactivated_by_name']; ?></td>
                                            <td><?= $row['deactivated_by_email']; ?></td>
                                            <td><?= $row['reason']; ?></td>
                                            <td><?= $row['deactivate_datetime']; ?></td>
                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "<tr><td colspan='7'>No records found</td></tr>";
                                }

                                $conn->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("../auth/footer.php");
?>
