<?php
session_start();
error_reporting(0);
if(!isset($_SESSION['id'])){
    header('location:login.php');
    exit;
}
?>
<?php
include("../auth/header.php");
include 'connection1.php';

if(isset($_GET['id'])){
    $uid = $_GET['id']; 

    $sql = "SELECT * FROM user WHERE id = $uid";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        $row = $result->fetch_array();
    }
}
?>

<div class="page-content">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $row['id'];?>">
                        <div class="mb-3">
                            <label for="exampleInputText1" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="exampleInputText1" value="<?php echo $row['name'];?>" placeholder="Enter Name" required>
                        </div>

                        <div class="mb-3">
                            <label for="exampleInputText1" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="exampleInputText1" value="<?php echo $row['email'];?>" placeholder="Enter Email" required>
                        </div>

                        <div>
                            Attach image
                            <br>
                            Select file
                            <input type="file" id="photo" name="image">
                            <br>
                            <?php if(!empty($row['photo'])): ?>
                                <img class="wd-80 ht-80 rounded-circle" src="image/<?php echo $row['photo'];?>" alt="profile">
                            <?php endif; ?>
                            <br>
                        </div>      

                        <button class="btn btn-primary" name="edit" type="submit">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div> 
</div>

<?php
if(isset($_POST['edit'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    $errors = array();
    $filename = $_FILES['image']['name']; 
    $filesize = $_FILES['image']['size'];
    $filetemp = $_FILES['image']['tmp_name'];
    $filetype = $_FILES['image']['type'];  
    
    $file_ext = strtolower(end(explode('.',$filename)));
    $extension = array("jpeg","jpg","png");

    if(!empty($filename)){
        if(in_array($file_ext, $extension) === false){
            $errors[] = "Extension not allowed. Please choose a JPG or PNG file.";
        }

        if($filesize > 2097152){
            $errors[] = "File size must be 2 MB or smaller.";
        }

        if(empty($errors)){
            $filename = rand(00, 99) . $filename;
            move_uploaded_file($filetemp, "image/" . $filename);
        } else {
            foreach($errors as $error){
                echo "<div class='error'>$error</div>";
            }
        }
    } else {
        $filename = $row['photo'];
    }

    if(empty($errors)){
        $sql_query = "UPDATE user SET name='$name', email='$email', photo='$filename' WHERE id='$id'";
        $result = $conn->query($sql_query);

        if($result == true){
            // Update session variables
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['photo'] = $filename; // Ensure the photo session variable is updated

            ?>
            <link rel="stylesheet" href="popup_style.css">
            <div class="popup popup--icon -success js_success-popup popup--visible">
                <div class="popup__background"></div>
                <div class="popup__content">
                    <h3 class="popup__content__title">Success</h3>
                    <p>Profile Updated Successfully</p>
                    <p>
                        <?php echo "<script>setTimeout(\"location.href = 'advocate_dashboard.php';\",1500);</script>"; ?>
                    </p>
                </div>
            </div>
            <?php
        } else {
            echo "SQL error: " . $conn->error;
        }
    }
}
?>
<?php 
include("../auth/footer.php");
?>
