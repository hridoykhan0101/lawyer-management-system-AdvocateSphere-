<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
include("../auth/header.php");
include("../auth/sidebar.php");
?>

<link rel="stylesheet" href="popup_style.css">
<div class="page-content">
   <?php
      if(isset($_GET['id']))
      { ?>  /* <!--  Author Name- Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website - www.mayurik.com -->
      } */
   <div class="popup popup--icon -question js_question-popup popup--visible">
      <div class="popup__background"></div>
      <div class="popup__content">
         <h3 class="popup__content__title">
         Sure
         </h1>
         <p>Are You Sure To Delete This Record?</p>
         <p></p>
         <p>
            <a href="delete_client.php?id=<?php echo $_GET['id']; ?>" class="btn btn-success" data-for="js_success-popup">Yes</a>
            <a href="client_data.php" class="btn btn-danger" data-for="js_success-popup">No</a>
         </p>
      </div>
   </div>
   <?php } ?>
   

<style>
    .table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin-bottom: 1rem;
        color: #212529;
    }
    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }
    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
        background-color: #f8f9fa;
        color: #495057;
        font-weight: bold;
    }
    .table tbody + tbody {
        border-top: 2px solid #dee2e6;
    }
    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.075);
    }
    .table-responsive {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
</style>

<div class="page-content">
    <!-- ... (popup code remains unchanged) ... -->

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Advocate Data</h6>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Gender</th>
                                    <th>DOB</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th>Birth Certificate</th>
                                    <th>NID No.</th>
                                    <th>Passport Number</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                include 'connection1.php';
                                
                                $sql = "SELECT * FROM clients";
                                $result = $conn->query($sql);
                                
                                if($result->num_rows > 0){
                                    while($row = $result->fetch_array()){
                                ?>
                                <tr>
                                    <td><?=$row['id'];?></td>
                                    <td><?=$row['name'];?></td>
                                    <td><?=$row['gender'];?></td>
                                    <td><?=$row['dob'];?></td>
                                    <td><?=$row['email'];?></td>
                                    <td><?=$row['mobile'];?></td>
                                    <td><?=$row['address'];?></td>
                                    <td><?=$row['birth_certificate'];?></td>
                                    <td><?=$row['nid_no'];?></td>
                                    <td><?=$row['passport_number'];?></td>
                                    <td><?php echo ($row['status'] == "0") ? "Active" : "Inactive";?></td>
                                    <td>
                                        <a class="btn btn-danger btn-sm" href="client_data.php?id=<?=$row['id'];?>"><i class="fa fa-trash text-white" aria-hidden="true"></i></a>
                                        <a class="btn btn-success btn-sm" href="edit_client.php?id=<?=$row['id'];?>"><i class="fa fa-edit text-white" aria-hidden="true"></i></a>
                                    </td>
                                    <td>
                                        <?php 
                                        if($row['status'] == "0") {
                                            echo "<a href=deactivate.php?id=".$row['id']." class='btn btn-danger btn-sm'>Deactivate</a>";
                                        } else {
                                            echo "<a href=activate.php?id=".$row['id']." class='btn btn-success btn-sm'>Activate</a>";
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php        
                                    }
                                } else {
                                    echo "<tr><td colspan='13'>No records found</td></tr>";
                                }
                                
                                $conn->close(); 
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
include("../auth/footer.php");
?>

