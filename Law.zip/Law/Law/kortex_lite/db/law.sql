-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2024 at 07:41 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `law`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `password`, `photo`) VALUES
(1, 'Hasinur Rahman', 'hasinurrahman01012018@gmail.com', '7e547ba8bfeeb4fcb09d9313e8eee598dc97ae5b99c0bfce30977d6dad336e48', '77eco park hridoy.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `advocates`
--

CREATE TABLE `advocates` (
  `id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `role` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `photo` blob NOT NULL,
  `status` varchar(30) NOT NULL,
  `action` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advocates`
--

INSERT INTO `advocates` (`id`, `name`, `gender`, `dob`, `email`, `password`, `mobile`, `role`, `address`, `photo`, `status`, `action`) VALUES
(33, 'Hridoy ', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '1234', '01680456000', 'Junior', 'mirpur 6,road 8,house 17,Dhaka\r\nmirpur 6,road 8,ho', 0x466163654170705f31363139303737313332313137202832292e6a7067, '', ''),
(37, 'Hridoy Khan', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', 'hasinur', '01777637585', 'Junior', 'mirpur 6,road 8,house 17,Dhaka\r\nmirpur 6,road 8,ho', 0x687269646f792e706e67, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `case_register`
--

CREATE TABLE `case_register` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `case_no` varchar(20) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `court` varchar(50) NOT NULL,
  `case_type` varchar(50) NOT NULL,
  `case_stage` varchar(50) NOT NULL,
  `legel_acts` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `filling_date` date NOT NULL,
  `hearing_date` date NOT NULL,
  `opposite_lawyer` varchar(50) NOT NULL,
  `total_fees` int(20) NOT NULL,
  `unpaid` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_register`
--

INSERT INTO `case_register` (`id`, `title`, `case_no`, `client_name`, `court`, `case_type`, `case_stage`, `legel_acts`, `description`, `filling_date`, `hearing_date`, `opposite_lawyer`, `total_fees`, `unpaid`) VALUES
(1, 'Landddd Dispute Case', '', '1', '2', '1', '1', '1', 'Dispute over land ownership between two parties.', '2024-07-07', '2024-07-07', 'John Smith', 5000, 2000),
(2, 'Divorce Case', 'DV002', '2', '3', '2', '2', '2', 'Legal separation between married couple.', '2023-07-10', '2024-02-20', 'Emily Johnson', 7500, 3000),
(3, 'Employment Discrimination Case', 'ED003', '3', '1', '1', '3', '4', 'Allegations of workplace discrimination.', '2023-09-05', '2024-03-10', 'Rachel White', 10000, 4000),
(4, 'Personal Injury Case', 'PI004', '4', '4', '1', '4', '3', 'Compensation claim for injuries sustained in a car accident.', '2023-10-15', '2024-04-05', 'Michael Brown', 8000, 2000),
(5, 'Criminal Case', 'CR005', '5', '6', '3', '5', '5', 'Alleged theft of property.', '2023-11-20', '2024-05-15', 'David Wilson', 12000, 6000),
(6, 'Child Custody Case', 'CC006', '6', '7', '2', '2', '6', 'Dispute over custody of children in divorce proceedings.', '2024-01-05', '2024-06-20', 'Sarah Davis', 9000, 3000),
(7, 'Tax Evasion Case', 'TE007', '7', '8', '1', '6', '7', 'Alleged evasion of taxes by a business entity.', '2024-02-10', '2024-07-05', 'Daniel Clark', 15000, 7000),
(8, 'Environmental Law Violation Case', 'EV008', '8', '10', '1', '7', '8', 'Violation of environmental regulations by a corporation.', '2024-03-20', '2024-08-10', 'Olivia Martinez', 11000, 5000),
(9, 'Employment Contract Dispute Case', 'EC009', '9', '9', '1', '3', '9', 'Dispute over terms of employment contract.', '2024-04-15', '2024-09-20', 'Matthew Garcia', 8500, 2000),
(10, 'Adoption Case', 'AD010', '10', '5', '2', '2', '10', 'Legal process of adopting a child.', '2024-05-10', '2024-10-15', 'Ava Lee', 9500, 4000),
(11, 'murder', '100', 'select client name', '3', '2', 'select case', '2', 'dxfgchjvbknlm', '2024-07-14', '2024-07-18', 'rabiul', 500000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `case_stage`
--

CREATE TABLE `case_stage` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL COMMENT '0-active,1-deactive'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_stage`
--

INSERT INTO `case_stage` (`id`, `name`, `status`) VALUES
(11, 'initiall', '1'),
(15, 'initial', '1'),
(14, 'asdfgbhn', '1'),
(4, 'Resolution Negotiation', 'Pending'),
(5, 'Final Decision', 'Pending'),
(6, 'Appeal Process', 'Pending'),
(7, 'Settlement', 'Completed'),
(8, 'Closure', 'Completed'),
(9, 'Reopening', 'Pending'),
(10, 'Litigation', 'Active'),
(16, 'ertyuio', '1');

-- --------------------------------------------------------

--
-- Table structure for table `case_types`
--

CREATE TABLE `case_types` (
  `id` int(11) NOT NULL,
  `case_type` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_types`
--

INSERT INTO `case_types` (`id`, `case_type`) VALUES
(1, 'Civil'),
(2, 'Criminal'),
(3, 'Family'),
(4, 'Employment'),
(5, 'Personal Injury'),
(6, 'Tax'),
(7, 'Environmental'),
(8, 'Contract'),
(9, 'Intellectual Property'),
(10, 'Immigration');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL COMMENT '0-active,1-deactive'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `gender`, `dob`, `email`, `mobile`, `address`, `status`) VALUES
(12, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'mirpur 6,road 8,house 17,Dhaka', ''),
(11, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'mirpur 6,road 8,house 17,Dhaka', ''),
(15, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'mirpur 6,road 8,house 17,Dhaka', ''),
(17, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(19, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01777637585', 'mirpur 6,road 8,house 17,Dhaka', ''),
(32, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', '', '01777637584', 'RADHAGOBINDAPUR DHALA', ''),
(33, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', '', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(10, 'Ava Garcia', 'Female', '1998-06-08', 'ava.garcia@example.com', '5678901234', '876 Elm St, Town, ', '0'),
(13, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01777637585', 'mirpur 6,road 8,house 17,Dhaka', ''),
(14, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01777637585', 'mirpur 6,road 8,house 17,Dhaka', ''),
(16, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'mirpur 6,road 8,house 17,Dhaka', ''),
(18, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(20, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01777637585', 'mirpur 6,road 8,house 17,Dhaka', ''),
(21, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(22, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(23, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(24, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(25, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(26, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(27, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(28, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(29, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(30, 'MD. HASINUR ROHMAN', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01680456000', 'RADHAGOBINDAPUR DHALA', ''),
(31, 'Hasinur Rahman', 'Male', '2004-12-16', 'hasinurrahman01012018@gmail.com', '01777637585', 'mirpur 6,road 8,house 17,Dhaka', '');

-- --------------------------------------------------------

--
-- Table structure for table `court`
--

CREATE TABLE `court` (
  `id` int(11) NOT NULL,
  `court_category` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court`
--

INSERT INTO `court` (`id`, `court_category`) VALUES
(1, 'Supreme Court'),
(2, 'High Court'),
(3, 'District Court'),
(4, 'Appellate Court'),
(5, 'Juvenile Court'),
(6, 'Family Court'),
(7, 'Tax Court'),
(8, 'Administrative Court'),
(9, 'Magistrate Court'),
(10, 'Probate Court');

-- --------------------------------------------------------

--
-- Table structure for table `legel_acts`
--

CREATE TABLE `legel_acts` (
  `id` int(11) NOT NULL,
  `act_name` varchar(50) NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `legel_acts`
--

INSERT INTO `legel_acts` (`id`, `act_name`, `status`) VALUES
(2, 'Family and Medical ', 0),
(3, 'Americans with Disabilities Act', 0),
(4, 'Civil Rights Act', 0),
(5, 'Fair Labor Standards Act', 0),
(6, 'Clean Air Act', 0),
(7, 'Occupational Safety and Health Act', 0),
(8, 'Freedom of Information Act', 0),
(9, 'National Environmental Policy Act', 0),
(10, 'Equal Pay Act', 0),
(11, 'Consumer Protection Act', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL,
  `photo` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `role`, `photo`) VALUES
(33, 'MD. HASINUR', 'hasinurrahman0101@gmail.com', '1122', 'Senior Advocate', 0x3636466163654170705f31363139303737313332313137202832292e6a7067),
(37, 'Hasinur Rahman', 'hridoykhan01012018@gmail.com', 'hasinur', 'Junior Advocate', 0x3333466163654170705f313632353038303036303836392e6a7067);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advocates`
--
ALTER TABLE `advocates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_register`
--
ALTER TABLE `case_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_stage`
--
ALTER TABLE `case_stage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `case_types`
--
ALTER TABLE `case_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `court`
--
ALTER TABLE `court`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `legel_acts`
--
ALTER TABLE `legel_acts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `advocates`
--
ALTER TABLE `advocates`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `case_register`
--
ALTER TABLE `case_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `case_stage`
--
ALTER TABLE `case_stage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `case_types`
--
ALTER TABLE `case_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `court`
--
ALTER TABLE `court`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `legel_acts`
--
ALTER TABLE `legel_acts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
