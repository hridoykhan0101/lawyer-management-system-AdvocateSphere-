<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}

include("../auth/header.php");
include 'connection1.php';
include("../auth/sidebar.php");

if(isset($_POST['update'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $role = $_POST['role'];
    $address = $_POST['address'];

    // Handle photo upload if provided
    if (!empty($_FILES['photo']['name'])) {
        $photo_name = $_FILES['photo']['name'];
        $photo_temp = $_FILES['photo']['tmp_name'];
        $photo_path = "../uploads/" . $photo_name;
        move_uploaded_file($photo_temp, $photo_path);
    } else {
        // Keep existing photo path if no new photo uploaded
        $sql_photo = "SELECT photo FROM advocates WHERE id = ?";
        $stmt_photo = $conn->prepare($sql_photo);
        $stmt_photo->bind_param("i", $id);
        $stmt_photo->execute();
        $stmt_photo->bind_result($existing_photo);
        $stmt_photo->fetch();
        $photo_path = $existing_photo;
        $stmt_photo->close();
    }

    // Get the old email before updating
    $sql_old_email = "SELECT email FROM advocates WHERE id = ?";
    $stmt_old_email = $conn->prepare($sql_old_email);
    $stmt_old_email->bind_param("i", $id);
    $stmt_old_email->execute();
    $stmt_old_email->bind_result($old_email);
    $stmt_old_email->fetch();
    $stmt_old_email->close();

    // Check if password is provided and update it if so
    if (!empty($_POST['password'])) {
        $password = $_POST['password'];
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql_update_advocate = "UPDATE advocates SET name = ?, gender = ?, dob = ?, email = ?, password = ?, mobile = ?, role = ?, address = ?, photo = ? WHERE id = ?";
        $stmt_advocate = $conn->prepare($sql_update_advocate);
        $stmt_advocate->bind_param("sssssssssi", $name, $gender, $dob, $email, $hashed_password, $mobile, $role, $address, $photo_path, $id);

        $sql_update_user = "UPDATE user SET email = ?, password = ? WHERE email = ?";
        $stmt_user = $conn->prepare($sql_update_user);
        $stmt_user->bind_param("sss", $email, $hashed_password, $old_email);
    } else {
        $sql_update_advocate = "UPDATE advocates SET name = ?, gender = ?, dob = ?, email = ?, mobile = ?, role = ?, address = ?, photo = ? WHERE id = ?";
        $stmt_advocate = $conn->prepare($sql_update_advocate);
        $stmt_advocate->bind_param("ssssssssi", $name, $gender, $dob, $email, $mobile, $role, $address, $photo_path, $id);

        $sql_update_user = "UPDATE user SET email = ? WHERE email = ?";
        $stmt_user = $conn->prepare($sql_update_user);
        $stmt_user->bind_param("ss", $email, $old_email);
    }

    if($stmt_advocate->execute() && $stmt_user->execute()){
        ?>
        <link rel="stylesheet" href="popup_style.css">
        <div class="popup popup--icon -success js_success-popup popup--visible">
          <div class="popup__background"></div>
          <div class="popup__content">
            <h3 class="popup__content__title">Success</h3>
            <p>Advocate Updated Successfully</p>
            <p>
             <?php echo "<script>setTimeout(\"location.href = 'advocate_data.php';\",1500);</script>"; ?>
            </p>
          </div>
        </div>
        <?php
    } else {
        echo "SQL error: " . $stmt_advocate->error . " " . $stmt_user->error;
    }
    $stmt_advocate->close();
    $stmt_user->close();
}

if(isset($_GET['id'])){
    $advocate_id = $_GET['id'];
    $advocate_sql = "SELECT * FROM advocates WHERE id = ?";
    $stmt = $conn->prepare($advocate_sql);
    $stmt->bind_param("i", $advocate_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $advocate_row = $result->fetch_assoc();
    }
    $stmt->close();
}
?>

<html>
<head>
    <link rel="stylesheet" href="../assets/css/demo1/style.css">
</head>
<body>    
    <div class="page-content">
     <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Edit Advocate</h6>
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?php echo $advocate_row['id'];?>">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="name" value="<?php echo $advocate_row['name'];?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Gender</label>
                            <div>
                                <input type="radio" name="gender" value="Male" <?php if($advocate_row['gender'] == 'Male') echo 'checked'; ?> required> Male
                                <input type="radio" name="gender" value="Female" <?php if($advocate_row['gender'] == 'Female') echo 'checked'; ?> required> Female
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Date of Birth</label>
                            <input type="date" class="form-control" name="dob" value="<?php echo $advocate_row['dob'];?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email" value="<?php echo $advocate_row['email'];?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password (Leave blank to keep current password)</label>
                            <input type="password" class="form-control" name="password" id="password">
                        </div>
                        
                        <div class="mb-3">
                            <label for="mobile" class="form-label">Mobile Number</label>
                            <input type="text" class="form-control" name="mobile" id="mobile" value="<?php echo $advocate_row['mobile'];?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-control" name="role" id="role" required>
                                <option value="Junior" <?php if($advocate_row['role'] == 'Junior') echo 'selected'; ?>>Junior</option>
                                <option value="Senior" <?php if($advocate_row['role'] == 'Senior') echo 'selected'; ?>>Senior</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" name="address" id="address" rows="3" required><?php echo $advocate_row['address'];?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="photo" class="form-label">Photo</label>
                            <input type="file" class="form-control" name="photo" id="photo">
                            <?php if(!empty($advocate_row['photo'])): ?>
                                <img src="<?php echo $advocate_row['photo']; ?>" alt="Current Photo" style="max-width: 200px; margin-top: 10px;">
                            <?php endif; ?>
                        </div>
                        
                        <button type="submit" name="update" class="btn btn-primary">Update Advocate</button>
                    </form>
                </div>
            </div>
        </div>
     </div>
    </div>
</body>
</html>

<?php
include("../auth/footer.php");
?>
