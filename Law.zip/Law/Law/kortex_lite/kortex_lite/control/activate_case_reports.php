<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
include("../auth/header.php");
include("../auth/sidebar.php");
include 'connection1.php';
?>

<link rel="stylesheet" href="popup_style.css">
<style>
    .table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin-bottom: 1rem;
        color: #212529;
    }
    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }
    .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
        background-color: #f8f9fa;
        color: #495057;
        font-weight: bold;
    }
    .table tbody + tbody {
        border-top: 2px solid #dee2e6;
    }
    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.075);
    }
    .table-responsive {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
</style>

<div class="page-content">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">Re-Activate Case Data</h6>
                    <?php
                    if(isset($_SESSION['success_message'])) {
                        echo '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
                        unset($_SESSION['success_message']);
                    }
                    if(isset($_SESSION['error_message'])) {
                        echo '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
                        unset($_SESSION['error_message']);
                    }
                    ?>
                    <div class="table-responsive">
                        <table id="dataTableExample" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Client Name</th>
                                    <th>Client Email</th>
                                    <th>Activated By Name</th>
                                    <th>Activated By Email</th>
                                    <th>Reason</th>
                                    <th>Activate Date & Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM re_activate_case";
                                $result = $conn->query($sql);
                                
                                if($result->num_rows > 0){
                                    while($row = $result->fetch_array()){
                                ?>
                                <tr>
                                    <td><?=$row['id'];?></td>
                                    <td><?=$row['client_name'];?></td>
                                    <td><?=$row['client_email'];?></td>
                                    <td><?=$row['activated_by_name'];?></td>
                                    <td><?=$row['activated_by_email'];?></td>
                                    <td><?=$row['reason'];?></td>
                                    <td><?=$row['activate_datetime'];?></td>
                                </tr>
                                <?php        
                                    }
                                } else {
                                    echo "<tr><td colspan='7'>No records found</td></tr>";
                                }
                                
                                $conn->close(); 
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
include("../auth/footer.php");
?>
