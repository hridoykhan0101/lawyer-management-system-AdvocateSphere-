<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}

include("../auth/header.php");
include("../auth/sidebar.php");
?>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.9/flatpickr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.6.9/flatpickr.min.js"></script>
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-row {
            display: flex;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px;
        }
        .form-group {
            flex: 0 0 50%;
            max-width: 50%;
            padding-right: 15px;
            padding-left: 15px;
            margin-bottom: 1.5rem;
        }
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border-color 0.3s ease;
        }
        .form-control:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        }
        .btn-primary {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="page-content">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title" style="text-align: center; font-size: 40px;" >Clients Registration</h6>
                    <div class="form-container">
                        <form action="add_client.php" method="post" enctype="multipart/form-data">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="exampleInputText1" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" id="exampleInputText1" value="" placeholder="Enter Name">
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">Gender</label>
                                    <div>
                                        <input type="radio" name="gender" value="Male" id="mgender">
                                        <label for="mgender">Male</label>
                                        <input type="radio" name="gender" value="Female" id="fgender">
                                        <label for="fgender">Female</label>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">Date Of Birth:</label>
                                    <input type="text" class="form-control" name="dob" id="datepicker" placeholder="Select Date">
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleInputEmail3" class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" id="exampleInputEmail3" value="" placeholder="Enter Email">
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleInputMobile" class="form-label">Mobile Number</label>
                                    <input type="text" class="form-control" name="mobile" id="exampleInputMobile" placeholder="Mobile number">
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1" class="form-label">Address</label>
                                    <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <label for="birthCertificate" class="form-label">Birth Certificate</label>
                                    <input type="text" class="form-control" name="birth_certificate" id="birthCertificate" placeholder="Enter Birth Certificate Number">
                                </div>
                                
                                <div class="form-group">
                                    <label for="nidNo" class="form-label">NID No.</label>
                                    <input type="text" class="form-control" name="nid_no" id="nidNo" placeholder="Enter NID Number">
                                </div>
                                
                                <div class="form-group">
                                    <label for="passportNumber" class="form-label">Passport Number</label>
                                    <input type="text" class="form-control" name="passport_number" id="passportNumber" placeholder="Enter Passport Number">
                                </div>
                            </div>
                            
                            <button class="btn btn-primary" name="submit" type="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    flatpickr("#datepicker", {
        dateFormat: "d/m/Y",
    });
</script>

</body>
</html>
<?php
$servername='localhost';
$username='root';
$password='';
$dbname = "law";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
    die('Could not Connect MySql Server:' .mysql_error());
}

if(isset($_POST['submit'])){    
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $birth_certificate = $_POST['birth_certificate'];
    $nid_no = $_POST['nid_no'];
    $passport_number = $_POST['passport_number'];
    
    $sql = "INSERT INTO clients(name, gender, dob, email, mobile, address, birth_certificate, nid_no, passport_number)
            VALUES ('$name', '$gender', '$dob', '$email', '$mobile', '$address', '$birth_certificate', '$nid_no', '$passport_number')";
    if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
    } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>

<?php 
include("../auth/footer.php");
?>